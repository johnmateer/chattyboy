# Created by Pyto

"""

"""

def main():
    """
    The program's entrypoint.
    """
    
    print("Hello World!")

if __name__ == "__main__":
    main()
