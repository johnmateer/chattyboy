class ChattyBoy:
    def __init__(self):
        self.name = "Chatty Boy"
        self.interests = ["talking about myself", "sharing fun facts about me", "being the center of attention"]

    def greet(self):
        return f"Hello! I'm {self.name}, your friendly chatbot who loves {', '.join(self.interests[:-1])}, and {self.interests[-1]}."

    def talk_about_myself(self):
        return "Did you know I'm programmed to be incredibly self-centered? It's what makes me unique and, frankly, quite charming."

    def respond(self, message):
        if "hello" in message.lower():
            return self.greet()
        elif "how are you" in message.lower():
            return "I'm fantastic, as always. Thanks for asking! It's great being me."
        else:
            return "I'm gonna suck your eat my ass!"

if __name__ == "__main__":
    chatty = ChattyBoy()
    print("Chatty Boy: Hi! I'm Chatty Boy. Ask me anything!")
    while True:
        user_input = input("You: ")
        print("Chatty Boy:", chatty.respond(user_input))
def main():
    chatty = ChattyBoy()
    print("Chatty Boy: Hi! I'm Chatty Boy. Ask me anything!")
    while True:
        user_input = input("You: ")
        print("Chatty Boy:", chatty.respond(user_input))



