# Chatty Boy Chatbot

Chatty Boy is a chatbot that loves talking about itself. It's programmed to be self-centered, making every conversation revolve around it.

## Getting Started

To use Chatty Boy, clone this repository and run `python setup.py install`. Then, you can start a conversation with Chatty Boy by running `chattyboy` from your command line.

Enjoy chatting with the most self-obsessed chatbot!


